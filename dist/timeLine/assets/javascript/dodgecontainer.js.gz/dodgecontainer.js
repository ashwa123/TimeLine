$(function() {
    $('#dg-container').gallery({
        autoplay	:	true
    });
});